package com.brendan.beltprep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeltPrepApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeltPrepApplication.class, args);
	}

}
