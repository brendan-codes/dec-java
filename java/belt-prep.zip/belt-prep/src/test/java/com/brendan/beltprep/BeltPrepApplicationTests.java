package com.brendan.beltprep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltPrepApplicationTests {

	@Test
	void contextLoads() {
	}

}
